T = int(input())
for _ in range(T):
    N = int(input())
    W = list(map(int, input().split()))
    cnt = W.count(1)
    print('L' if cnt % 2 == 1 else 'Q')