import sys

MOD = 998244353

def get_prefix(X: int, Y: int, t: int) -> int:
    """
    返回矩形 [0, X] × [0, Y] 中满足 x+y <= t 的点数。
    """
    if t < 0:
        return 0
    total = (X + 1) * (Y + 1)
    if t >= X + Y:
        return total
    m = min(X, Y)
    M = max(X, Y)
    if t <= m:
        # 等差数列求和 1+2+...+(t+1)
        return (t + 1) * (t + 2) // 2
    if t <= M:
        fm = (m + 1) * (m + 2) // 2
        return fm + (t - m) * (m + 1)
    # M < t < X+Y
    d = X + Y - t
    return total - d * (d + 1) // 2


def solve() -> None:
    data = sys.stdin.buffer.read().split()
    if not data:
        return
    it = iter(data)
    n = int(next(it))
    a = [0] + [int(next(it)) for _ in range(n)]          # 1‑based

    # 左边第一个大于 a[i] 的位置 (L[i])
    L = [0] * (n + 2)
    stack = []
    for i in range(1, n + 1):
        while stack and a[stack[-1]] <= a[i]:
            stack.pop()
        L[i] = stack[-1] if stack else 0
        stack.append(i)

    # 右边第一个大于等于 a[i] 的位置 (R[i])
    R = [n + 1] * (n + 2)
    stack.clear()
    for i in range(n, 0, -1):
        while stack and a[stack[-1]] < a[i]:
            stack.pop()
        R[i] = stack[-1] if stack else n + 1
        stack.append(i)

    # 预处理位数分段
    max_len = n
    max_k = len(str(max_len))
    segments = []          # (k, low, high)
    for k in range(1, max_k + 1):
        low = 10 ** (k - 1)
        high = min(10 ** k - 1, n)
        if low > high:
            continue
        segments.append((k, low, high))

    ans = 0
    for i in range(1, n + 1):
        X = i - L[i] - 1
        Y = R[i] - i - 1
        total = 0
        for k, low, high in segments:
            A = low - 1
            B = high - 1
            cnt = get_prefix(X, Y, B) - get_prefix(X, Y, A - 1)
            total += k * cnt
        ans = (ans + a[i] * total) % MOD

    print(ans)


if __name__ == "__main__":
    solve()