import math

def main():
    A = 20269876543210
    B = 20260123456789
    MOD = 998244353
    S_max = A + B

    # 计算各区间分界点的整数平方根
    K1 = math.isqrt(B)          # 最大的 k 使得 k^2 ≤ B
    K2 = math.isqrt(A)          # 最大的 k 使得 k^2 ≤ A
    K3 = math.isqrt(S_max)      # 最大的 k 使得 k^2 ≤ S_max

    # 平方和公式: sum_{k=0}^{n} k^2 = n(n+1)(2n+1)//6
    def sum_sq(n: int) -> int:
        return n * (n + 1) * (2 * n + 1) // 6

    ans = 0

    # 第一段: k = 0 .. K1，贡献为 k^2 + 1
    if K1 >= 0:
        total1 = sum_sq(K1) + (K1 + 1)
        ans = (ans + total1) % MOD

    # 第二段: k = K1+1 .. K2，贡献为常数 B+1
    if K2 > K1:
        cnt2 = K2 - K1
        total2 = cnt2 * (B + 1)
        ans = (ans + total2) % MOD

    # 第三段: k = K2+1 .. K3，贡献为 S_max - k^2 + 1
    if K3 > K2:
        cnt3 = K3 - K2
        sum_sq_3 = sum_sq(K3) - sum_sq(K2)   # ∑_{k=K2+1}^{K3} k^2
        total3 = cnt3 * (S_max + 1) - sum_sq_3
        ans = (ans + total3) % MOD

    print(ans)

if __name__ == "__main__":
    main()