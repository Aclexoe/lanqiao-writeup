MOD = 10**9 + 7
N, K = map(int, input().split())
max_l = 20
prev_dp = [[0] * (max_l + 1) for _ in range(K + 1)]
prev_dp[0][0] = 1
for _ in range(N):
	curr_dp = [[0] * (max_l + 1) for _ in range(K + 1)]
	for j_prev in range(K + 1):
		for l_prev in range(max_l + 1):
			val = prev_dp[j_prev][l_prev]
			if val == 0:continue
			curr_dp[j_prev][0] = (curr_dp[j_prev][0] + val) % MOD
			l_new = l_prev + 1
			delta = l_new
			j_new = j_prev + delta
			if j_new > K:
				j_new = K
			if l_new > max_l:
				l_new = max_l
			curr_dp[j_new][l_new] = (curr_dp[j_new][l_new] + val) % MOD
	prev_dp = curr_dp
print(sum(prev_dp[K][l] for l in range(max_l + 1)) % MOD)