c, s = 0, 0


def getpow(v):
    return 10 ** len(str(v))


for i in range(1, 2027):
    s = s * getpow(i) + i
    if s % 26 == 0:
        c += 1
print(c)
