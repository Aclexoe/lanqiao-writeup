import math
def is_prime(x):
    if x <= 2:
        return (False,False,True)[x]
    for i in range(2 , math.isqrt(x)+1):
            if x % i == 0:
                return False
    return True
T = int(input())
for _ in range(T):
    n = int(input())
    if n <= 4:
        print(4)
    else:
        if is_prime(n):
            print(n+1)
        else:
            print(n)