import sys
sys.setrecursionlimit(1 << 25)

p = []
personal = []
delta = []
add = []
output = []

def find(x):
    global p, delta
    if p[x] != x:
        orig_parent = p[x]
        p[x] = find(p[x])
        delta[x] += delta[orig_parent]
    return p[x]

def union_sets(X, Y):
    global p, delta, add
    fx = find(X)
    fy = find(Y)
    if fx != fy:
        p[fy] = fx
        delta[fy] = add[fy] - add[fx]

def read_initial():
    first_line = sys.stdin.readline()
    while first_line.strip() == '':
        first_line = sys.stdin.readline()
    return map(int, first_line.split())

def init_arrays(N):
    global p, personal, delta, add
    p = list(range(N + 1))
    personal = [0] * (N + 1)
    delta = [0] * (N + 1)
    add = [0] * (N + 1)

def read_command():
    line = sys.stdin.readline()
    while line.strip() == '':
        line = sys.stdin.readline()
    return line.split()

def process_command(parts):
    global personal, add, output
    op = int(parts[0])
    if op == 1:
        X = int(parts[1])
        Y = int(parts[2])
        union_sets(X, Y)
    elif op == 2:
        X = int(parts[1])
        A = int(parts[2])
        personal[X] += A
    elif op == 3:
        X = int(parts[1])
        A = int(parts[2])
        fx = find(X)
        add[fx] += A
    elif op == 4:
        X = int(parts[1])
        fx = find(X)                 # 原代码缺失此行
        res = personal[X] + delta[X] + add[fx]
        output.append(str(res))

def print_output():
    print('\n'.join(output))

def main():
    N, Q = read_initial()
    init_arrays(N)
    for _ in range(Q):
        parts = read_command()
        process_command(parts)
    print_output()

main()