import sys
import math
import random
from typing import List, Tuple

# 使用更快的输入输出
input = sys.stdin.readline

def miller_rabin(n: int) -> bool:
    """优化的Miller-Rabin素数测试"""
    if n < 4:
        return n > 1
    if n % 2 == 0:
        return False
    
    # 小素数快速检查
    small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    for p in small_primes:
        if n == p:
            return True
        if n % p == 0:
            return False
    
    # 计算d和s，使得n-1 = d * 2^s
    d = n - 1
    s = 0
    while d % 2 == 0:
        s += 1
        d //= 2
    
    # 测试基数
    if n < 2047:
        bases = [2]
    elif n < 1373653:
        bases = [2, 3]
    elif n < 9080191:
        bases = [31, 73]
    elif n < 25326001:
        bases = [2, 3, 5]
    elif n < 3215031751:
        bases = [2, 3, 5, 7]
    elif n < 4759123141:
        bases = [2, 7, 61]
    elif n < 1122004669633:
        bases = [2, 13, 23, 1662803]
    elif n < 2152302898747:
        bases = [2, 3, 5, 7, 11]
    elif n < 3474749660383:
        bases = [2, 3, 5, 7, 11, 13]
    elif n < 341550071728321:
        bases = [2, 3, 5, 7, 11, 13, 17]
    else:
        bases = [2, 325, 9375, 28178, 450775, 9780504, 1795265022]
    
    for a in bases:
        if a >= n:
            continue
        
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            continue
        
        for _ in range(s - 1):
            x = (x * x) % n
            if x == n - 1:
                break
        else:
            return False
    
    return True

def gcd(a: int, b: int) -> int:
    """快速GCD"""
    while b:
        a, b = b, a % b
    return a

def pollard_rho(n: int) -> int:
    """优化的Pollard-Rho算法"""
    if n % 2 == 0:
        return 2
    if n % 3 == 0:
        return 3
    
    # 使用固定参数加速
    while True:
        c = random.randrange(1, n)
        f = lambda x: (x * x + c) % n
        x = y = 2
        d = 1
        
        while d == 1:
            x = f(x)
            y = f(f(y))
            d = gcd(abs(x - y), n)
        
        if d != n:
            return d

def factorize(n: int) -> List[Tuple[int, int]]:
    """优化的因式分解"""
    if n < 2:
        return []
    
    if miller_rabin(n):
        return [(n, 1)]
    
    # 小因数快速处理
    small_factors = []
    for p in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]:
        if n % p == 0:
            cnt = 0
            while n % p == 0:
                cnt += 1
                n //= p
            small_factors.append((p, cnt))
    
    if n > 1:
        if miller_rabin(n):
            small_factors.append((n, 1))
        else:
            # 对大数进行Pollard-Rho分解
            m = pollard_rho(n)
            c = 0
            while n % m == 0:
                c += 1
                n //= m
            
            factors = factorize(n) + factorize(m)
            for i in range(len(factors)):
                if factors[i][0] == m:
                    factors[i] = (m, factors[i][1] * c)
            
            # 合并结果
            factors.extend(small_factors)
            factors.sort()
            
            # 合并相同因数
            result = []
            for p, cnt in factors:
                if result and result[-1][0] == p:
                    result[-1] = (p, result[-1][1] + cnt)
                else:
                    result.append((p, cnt))
            return result
    
    return small_factors

def solve():
    """主解决函数"""
    t_case = int(input())
    out = []
    
    for _ in range(t_case):
        n, m = map(int, input().split())
        n = min(n, m)
        
        if n < m - (m & 1):
            out.append("-1")
            continue
        
        if m & 1:  # m是奇数
            factors = factorize(m)
            found = False
            for p, _ in factors:
                # 计算2是模p的原根
                exp = (p - 1) // ((p - 1) & (1 - p))
                if pow(2, exp, p) == 1:
                    out.append("-1")
                    found = True
                    break
            
            if not found:
                out.append(str((m + 1) >> 1))
        else:  # m是偶数
            # 计算m的最大奇因数
            lowbit = m & -m
            result = m - m // lowbit
            out.append(str(result))
    
    sys.stdout.write("\n".join(out))

if __name__ == "__main__":
    solve()